package data.scripts;


import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import org.json.JSONArray;

public class GDModPlugin extends BaseModPlugin {
	@Override
    public void onApplicationLoad() throws Exception {
        JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
        // Sets sizes 9-10 to 4-5 respectively.
        if (Global.getSettings().getBoolean("BCChangeIndustrySize")) {
            for (int i = 8; i < 10; i++) {
                maxIndustries.put(i, (int) maxIndustries.get(i)+1);
            }
        }
    }
    
    public void onGameLoad(boolean newGame) {
        if (Global.getSector().getEconomy().getMarket("epiphany") != null) Global.getSector().getEconomy().getMarket("epiphany").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("gilead") != null) Global.getSector().getEconomy().getMarket("gilead").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("jangala") != null) Global.getSector().getEconomy().getMarket("jangala").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("tartessus") != null) Global.getSector().getEconomy().getMarket("tartessus").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("hesperus") != null) Global.getSector().getEconomy().getMarket("hesperus").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("chalcedon") != null) Global.getSector().getEconomy().getMarket("chalcedon").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("mazalot") != null) Global.getSector().getEconomy().getMarket("mazalot").addCondition("bc_luddicfaith");
    }
    
    
}
