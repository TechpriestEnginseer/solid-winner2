package data.scripts;


import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import org.json.JSONArray;
import org.json.JSONObject;

public class GDModPlugin extends BaseModPlugin {
    

	public static boolean revertToVanilla = false;
        public JSONArray spreadsheet;
	@Override
	public void onApplicationLoad() throws Exception {
                if (!Global.getSettings().getModManager().isModEnabled("lw_lazylib"))
                {
                    throw new RuntimeException("Better Colonies requires LazyLib!"
                            + "\nGet it at http://fractalsoftworks.com/forum/index.php?topic=5444");
                }
		//JSONObject settings = Global.getSettings().loadJSON( "wyv_gd_settings.json" );
		//revertToVanilla = settings.getBoolean( "revertToVanillaIndustryBehavior" );
                JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
                // Sets sizes 9-10 to 4-5 respectively.
                for (int i = 8; i < 10; i++) {
                    maxIndustries.put(i, (int) maxIndustries.get(i)+1);
                }
	}

//	@Override
//	public void onEnabled( boolean wasEnabledBefore ) {
//            SectorAPI sector = Global.getSector();
//            if( sector != null ) {
//                if (!wasEnabledBefore)
//                {
//                    throw new RuntimeException("Sorry for the inconvenience. This mod does not work with saves that did not originally start with Better Colonies.");
//                }
//            }
//	}
}			/* EconomyAPI econ = sector.getEconomy();
			if( econ != null ) {
				List markets = econ.getMarketsCopy();
				for( int i = 0; i < markets.size(); i++ ) {
					MarketAPI market = (MarketAPI)markets.get( i );
					if( market != null ) {
						Object TMObj = market.getIndustry( "techmining" );
						if( TMObj != null && TMObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.TechMining ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.TechMining shield = (com.fs.starfarer.api.impl.campaign.econ.impl.TechMining)TMObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "techmining", null, false );
							market.addIndustry( "techmining" );
							data.scripts.TechMining newTM = (data.scripts.TechMining)market.getIndustry( "techmining" );
							if( build > 0 ) newTM.setNewBuild( build );
							if( disrupted > 0 ) newTM.setDisrupted( disrupted );
						}
                                                Object OSLObj = market.getIndustry( "orbitalstation" );
						if( OSLObj != null && OSLObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)OSLObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "orbitalstation", null, true );
							market.addIndustry( "orbitalstation" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newOSL = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "orbitalstation" );
							/*if( build > 0 ) newOSL.setNewBuild( build );
							if( disrupted > 0 ) newOSL.setDisrupted( disrupted, true );*/
						/* }
                                                Object BSLObj = market.getIndustry( "battlestation" );
						if( BSLObj != null && BSLObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)BSLObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "battlestation", null, true );
							market.addIndustry( "battlestation" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newBSL = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "battlestation" );
							/*if( build > 0 ) newBSL.setNewBuild( build );
							if( disrupted > 0 ) newBSL.setDisrupted( disrupted, true );*/
						/* }
                                                Object SFLObj = market.getIndustry( "starfortress" );
                                                if( SFLObj != null && SFLObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)SFLObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "starfortress", null, true );
							market.addIndustry( "starfortress" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newSFL = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "starfortress" );
							/*if( build > 0 ) newSFL.setNewBuild( build );
							if( disrupted > 0 ) newSFL.setDisrupted( disrupted, true );*/
						/* }
                                                Object OSMObj = market.getIndustry( "orbitalstation_mid" );
                                                if( OSMObj != null && OSMObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)OSMObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "orbitalstation_mid", null, true );
							market.addIndustry( "orbitalstation_mid" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newOSM = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "orbitalstation_mid" );
							/*if( build > 0 ) newOSM.setNewBuild( build );
							if( disrupted > 0 ) newOSM.setDisrupted( disrupted, true );*/
						/* }
                                                Object BSMObj = market.getIndustry( "battlestation_mid" );
                                                if( BSMObj != null && BSMObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)BSMObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "battlestation_mid", null, true );
							market.addIndustry( "battlestation_mid" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newBSM = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "battlestation_mid" );
							/*if( build > 0 ) newBSM.setNewBuild( build );
							if( disrupted > 0 ) newBSM.setDisrupted( disrupted, true );*/
						/* }
                                                Object SFMObj = market.getIndustry( "starfortress_mid" );
                                                if( SFMObj != null && SFMObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)SFMObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "starfortress_mid", null, true );
							market.addIndustry( "starfortress_mid" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newSFM = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "starfortress_mid" );
							/*if( build > 0 ) newSFM.setNewBuild( build );
							if( disrupted > 0 ) newSFM.setDisrupted( disrupted, true );*/
						/*}
                                                Object OSHObj = market.getIndustry( "orbitalstation_high" );
                                                if( OSHObj != null && OSHObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)OSHObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "orbitalstation_high", null, true );
							market.addIndustry( "orbitalstation_high" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newOSH = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "orbitalstation_high" );
							/*if( build > 0 ) newOSH.setNewBuild( build );
							if( disrupted > 0 ) newOSH.setDisrupted( disrupted, true );*/
						/*}
                                                Object BSHObj = market.getIndustry( "battlestation_high" );
                                                if( BSHObj != null && BSHObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)BSHObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "battlestation_high", null, true );
							market.addIndustry( "battlestation_high" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newBSH = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "battlestation_high" );
							/*if( build > 0 ) newBSH.setNewBuild( build );
							if( disrupted > 0 ) newBSH.setDisrupted( disrupted, true );*/
						/*}
                                                Object SFHObj = market.getIndustry( "starfortress_high" );
                                                if( SFHObj != null && SFHObj instanceof com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation shield = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation)SFHObj;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "starfortress_high", null, true );
							market.addIndustry( "starfortress_high" );
							com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD newSFH = (com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStationGD)market.getIndustry( "starfortress_high" );
							/*if( build > 0 ) newSFH.setNewBuild( build );
							if( disrupted > 0 ) newSFH.setDisrupted( disrupted, true );*/
						/*}
                                                Object CryoR = market.getIndustry( "cryorevival" );
                                                if( CryoR != null && CryoR instanceof com.fs.starfarer.api.impl.campaign.econ.impl.Cryorevival ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.Cryorevival shield = (com.fs.starfarer.api.impl.campaign.econ.impl.Cryorevival)CryoR;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "cryorevival", null, false );
							market.addIndustry( "cryorevival" );
							com.fs.starfarer.api.impl.campaign.econ.impl.CryorevivalGD newCryoR = (com.fs.starfarer.api.impl.campaign.econ.impl.CryorevivalGD)market.getIndustry( "cryorevival" );
							if( build > 0 ) newCryoR.setNewBuild( build );
							if( disrupted > 0 ) newCryoR.setDisrupted( disrupted );
						}
                                                Object CryoS = market.getIndustry( "cryosanctum" );
                                                if( CryoS != null && CryoS instanceof com.fs.starfarer.api.impl.campaign.econ.impl.Cryosanctum ) {
							com.fs.starfarer.api.impl.campaign.econ.impl.Cryosanctum shield = (com.fs.starfarer.api.impl.campaign.econ.impl.Cryosanctum)CryoS;
							float disrupted = shield.getDisruptedDays();
							float build = shield.getBuildOrUpgradeProgress();
							market = econ.getMarket( market.getId() );
							market.removeIndustry( "cryosanctum", null, false );
							market.addIndustry( "cryosanctum" );
							com.fs.starfarer.api.impl.campaign.econ.impl.CryosanctumGD newCryoS = (com.fs.starfarer.api.impl.campaign.econ.impl.CryosanctumGD)market.getIndustry( "cryosanctum" );
							if( build > 0 ) newCryoS.setNewBuild( build );
							if( disrupted > 0 ) newCryoS.setDisrupted( disrupted );
						}
						econ.getMarket( market.getId() ).reapplyIndustries();
					}*/
