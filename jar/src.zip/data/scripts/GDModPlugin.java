package data.scripts;


import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import exerelin.ExerelinConstants;
import exerelin.campaign.intel.rebellion.RebellionCreator;
import exerelin.campaign.intel.rebellion.RebellionIntel;
import exerelin.utilities.NexConfig;
import org.json.JSONArray;

public class GDModPlugin extends BaseModPlugin {
	@Override
    public void onApplicationLoad() throws Exception {
        JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
        // Sets sizes 9-10 to 4-5 respectively.
        if (Global.getSettings().getBoolean("BCChangeIndustrySize")) {
            for (int i = 8; i < 10; i++) {
                maxIndustries.put(i, (int) maxIndustries.get(i)+1);
            }
        }
    }
    
    public void onGameLoad(boolean newGame) {
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            if (market.hasCondition("bc_luddicfaith")) {market.removeCondition("bc_luddicfaith");market.addCondition("bc_luddicfaith");}
        }
        if (Global.getSector().getEconomy().getMarket("epiphany") != null) Global.getSector().getEconomy().getMarket("epiphany").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("epiphany").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("gilead") != null) Global.getSector().getEconomy().getMarket("gilead").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("gilead").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("jangala") != null) Global.getSector().getEconomy().getMarket("jangala").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("jangala").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("tartessus") != null) Global.getSector().getEconomy().getMarket("tartessus").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("tartessus").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("hesperus") != null) Global.getSector().getEconomy().getMarket("hesperus").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("hesperus").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("chalcedon") != null) Global.getSector().getEconomy().getMarket("chalcedon").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("chalcedon").addCondition("bc_luddicfaith");
        if (Global.getSector().getEconomy().getMarket("mazalot") != null) Global.getSector().getEconomy().getMarket("mazalot").removeCondition("bc_luddicfaith");Global.getSector().getEconomy().getMarket("mazalot").addCondition("bc_luddicfaith");
        if (Global.getSettings().getModManager().isModEnabled("nexerelin") && NexConfig.enableInvasions) {
            Global.getSector().addTransientListener(new LuddicCheck());
        }
    }
    
    public static class LuddicCheck extends BaseCampaignEventListener {
        LuddicCheck() {
            super(false);
        }
        
        @Override
        public void reportEconomyMonthEnd() {
            if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 0.5f) {
                for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
                    if (!market.getFaction().getId().equals(Factions.LUDDIC_CHURCH) && market.hasCondition("bc_luddicfaith") && !market.hasIndustry("bc_luddic") && RebellionIntel.getOngoingEvent(market) == null && !Misc.isStoryCritical(market) && !market.getMemoryWithoutUpdate().getBoolean(ExerelinConstants.MEMORY_KEY_NPC_NO_INVADE)) {
                        RebellionCreator.getInstance().createRebellion(market, Factions.LUDDIC_CHURCH, true);
                    }
                }
            }
        }
    }
}
