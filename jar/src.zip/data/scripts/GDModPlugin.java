package data.scripts;


import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import org.json.JSONArray;

public class GDModPlugin extends BaseModPlugin {
	@Override
	public void onApplicationLoad() throws Exception {
        JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
        // Sets sizes 9-10 to 4-5 respectively.
        if (Global.getSettings().getBoolean("BCChangeIndustrySize")) {
            for (int i = 8; i < 10; i++) {
                maxIndustries.put(i, (int) maxIndustries.get(i)+1);
            }
        }
    }
}
