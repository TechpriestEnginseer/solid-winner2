package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.intel.misc.bc_SPNotification;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lunalib.lunaSettings.LunaSettings;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GDModPlugin extends BaseModPlugin {
        public static String[] SupportedFaction = new String[]{
        };
        public static Map<String, Float> SupportedIndustries = new HashMap();
        
    public void onApplicationLoad() throws Exception {
        JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
        // Sets sizes 9-10 to 4-5 respectively.
        if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCChangeIndustrySize") : Global.getSettings().getBoolean("BCChangeIndustrySize")) {
            for (int i = 8; i < 10; i++) {
                maxIndustries.put(i, (int) maxIndustries.get(i)+1);
            }
        }
        if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCAutoImproveIndustry") : Global.getSettings().getBoolean("BCAutoImproveIndustry")) {
            try {
                List<String> EligibleFactions = new ArrayList<>();
                JSONArray modFactionsCsv = Global.getSettings().getMergedSpreadsheetDataForMod("faction", "data/config/BetterColonyConfig/bc_autospfactions.csv", "timid_admins");
                for(int i = 0; i < modFactionsCsv.length(); i++) {
                    JSONObject row = modFactionsCsv.getJSONObject(i);
                    String factionName = row.getString("faction");
                    if (!factionName.equals("player")) EligibleFactions.add(factionName);
                }
                SupportedFaction = EligibleFactions.toArray(new String[]{});
            } catch (IOException | JSONException sex) {}
            try {
                JSONArray modIndustryCsv = Global.getSettings().getMergedSpreadsheetDataForMod("industry", "data/config/BetterColonyConfig/bc_autospindustries.csv", "timid_admins");
                for(int i = 0; i < modIndustryCsv.length(); i++) {
                    JSONObject row = modIndustryCsv.getJSONObject(i);
                    SupportedIndustries.put(row.getString("industry"), (float) row.getDouble("weight"));
                }
                
            } catch (IOException | JSONException sex) {}
        }
        //if (!Global.getSettings().getMissionSpec("mcb").getTagsAny().contains("bc_church")) {Global.getSettings().getMissionSpec("mcb").getTagsAny().add("bc_church");}
        //if (!Global.getSettings().getMissionSpec("sitm").getTagsAny().contains("bc_church")) {Global.getSettings().getMissionSpec("sitm").getTagsAny().add("bc_church");}
        //if (!Global.getSettings().getMissionSpec("dhi").getTagsAny().contains("bc_church")) {Global.getSettings().getMissionSpec("dhi").getTagsAny().add("bc_church");}
        //if (!Global.getSettings().getMissionSpec("ssat").getTagsAny().contains("bc_church")) {Global.getSettings().getMissionSpec("ssat").getTagsAny().add("bc_church");}
        //if (!Global.getSettings().getMissionSpec("psb").getTagsAny().contains("bc_church")) {Global.getSettings().getMissionSpec("ssat").getTagsAny().add("bc_church");}
    }
    
    /*public void MakePerson(MarketAPI market) {
            PersonAPI person = Global.getSector().getFaction(Factions.LUDDIC_CHURCH).createRandomPerson();
            person.setRankId(person.isFemale() ? Ranks.SISTER : Ranks.BROTHER);
            person.setPostId(Ranks.POST_COMMUNE_LEADER);
            person.setImportance(PersonImportance.MEDIUM);
            person.addTag("bc_church");
            market.getCommDirectory().addPerson(person);
            market.addPerson(person);
            //Global.getSector().getImportantPeople().addPerson(person);
    }*/
    
    public void onGameLoad(boolean newGame) {
        
        /*if (Global.getSector().getEconomy().getMarket("epiphany") != null && !Global.getSector().getEntityById("epiphany").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("epiphany").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("epiphany").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("epiphany").addCondition("bc_luddicfaith");Global.getSector().getEntityById("epiphany").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}
        if (Global.getSector().getEconomy().getMarket("gilead") != null && !Global.getSector().getEntityById("gilead").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("gilead").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("gilead").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("gilead").addCondition("bc_luddicfaith");Global.getSector().getEntityById("gilead").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}
        if (Global.getSector().getEconomy().getMarket("jangala") != null && !Global.getSector().getEntityById("jangala").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("jangala").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("jangala").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("jangala").addCondition("bc_luddicfaith");Global.getSector().getEntityById("jangala").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}
        if (Global.getSector().getEconomy().getMarket("tartessus") != null && !Global.getSector().getEntityById("tartessus").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("tartessus").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("tartessus").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("tartessus").addCondition("bc_luddicfaith");Global.getSector().getEntityById("tartessus").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}
        if (Global.getSector().getEconomy().getMarket("hesperus") != null && !Global.getSector().getEntityById("hesperus").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("hesperus").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("hesperus").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("hesperus").addCondition("bc_luddicfaith");Global.getSector().getEntityById("hesperus").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}
        if (Global.getSector().getEconomy().getMarket("chalcedon") != null && !Global.getSector().getEntityById("chalcedon").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("chalcedon").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("chalcedon").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("chalcedon").addCondition("bc_luddicfaith");Global.getSector().getEntityById("chalcedon").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}
        if (Global.getSector().getEconomy().getMarket("mazalot") != null && !Global.getSector().getEntityById("mazalot").getMarket().getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {if (Global.getSector().getEconomy().getMarket("mazalot").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("mazalot").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("mazalot").addCondition("bc_luddicfaith");Global.getSector().getEntityById("mazalot").getMarket().getMemoryWithoutUpdate().set("$bc_shrine", true);}*/
        //for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            //if (market.hasCondition("bc_luddicfaith") && !market.getMemoryWithoutUpdate().getBoolean("$bc_shrine")) {market.removeCondition("bc_luddicfaith");market.addCondition("bc_luddicfaith");market.getMemoryWithoutUpdate().set("$bc_shrine", true);MakePerson(market);}
        //}
        if (Global.getSettings().getModManager().isModEnabled("nexerelin")) {
            /*if (NexConfig.enableInvasions) {
                Global.getSector().addTransientListener(new LuddicCheck());
            }*/
            if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCLoseSPImprovements") : Global.getSettings().getBoolean("BCLoseSPImprovements")) {
                Global.getSector().getListenerManager().addListener(new BCLoseSPImprovements(), true);
            }
        }
        if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCAutoImproveIndustry") : Global.getSettings().getBoolean("BCAutoImproveIndustry")) {
            Global.getSector().addTransientListener(new LuddicCheck2());
        }
    }
    
    
    /*public static class LuddicCheck extends BaseCampaignEventListener {
        LuddicCheck() {
            super(false);
        }
        
        @Override
        public void reportEconomyMonthEnd() {
            if (!Misc.getFactionMarkets(Factions.LUDDIC_CHURCH).isEmpty() && Global.getSettings().getBoolean("BCEnableLuddicNexRebels")) {
                if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 0.5f) {
                    for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
                        if (!market.getFaction().getId().equals(Factions.LUDDIC_CHURCH) && market.hasCondition("bc_luddicfaith") && !market.hasIndustry("bc_luddic") && RebellionIntel.getOngoingEvent(market) == null && !Misc.isStoryCritical(market) && !market.getMemoryWithoutUpdate().getBoolean(ExerelinConstants.MEMORY_KEY_NPC_NO_INVADE) && !market.getMemoryWithoutUpdate().getBoolean("$bc_luddicrebelled")) {
                            RebellionCreator.getInstance().createRebellion(market, Factions.LUDDIC_CHURCH, true);
                            market.getMemoryWithoutUpdate().set("$bc_luddicrebelled", true, 365f);
                        }
                    }
                }
            }
        }
    }*/
    
    public static class LuddicCheck2 extends BaseCampaignEventListener {
        LuddicCheck2() {
            super(false);
        }
        
        @Override
        public void reportEconomyMonthEnd() {
            if (SupportedFaction != null) {
                if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCAgeOfInnovation") : Global.getSettings().getFloat("BCAgeOfInnovation"))) {
                    List<String> text = new ArrayList<String>();
                    List<Color> factionColor = new ArrayList<>();
                    List<String> highlighttext = new ArrayList<String>();
                    List<String> highlighttext2 = new ArrayList<String>();
                    String date = Global.getSector().getClock().getMonthString()+" "+Global.getSector().getClock().getCycleString();
                    if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCIgnoreFactionWhiteflag") : Global.getSettings().getBoolean("BCIgnoreFactionWhiteflag")) {
                        for (FactionAPI faction : Global.getSector().getAllFactions()) {
                            if (Global.getSector().getPlayerFaction() == faction) continue;
                            for (MarketAPI market : Misc.getFactionMarkets(faction.getId())) {
                                if (market != null && Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= (Global.getSector().getFaction(faction.getId()).getCustomBoolean("decentralized") ? (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCInnovatedDecentralized") : Global.getSettings().getFloat("BCInnovatedDecentralized")) : (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCInnovatedCentralized") : Global.getSettings().getFloat("BCInnovatedCentralized")))*market.getIndustries().size()) {
                                    if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 1/Math.pow(Math.max(1f, Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCSPIndustryMultiplier") : Global.getSettings().getFloat("BCSPIndustryMultiplier")), Misc.getNumImprovedIndustries(market))) {
                                        WeightedRandomPicker<String> AmongUs = new WeightedRandomPicker<String>();
                                        for (Industry industry : market.getIndustries()) {
                                            if (industry.isImproved()) continue;
                                            if (industry.canImprove() && industry.isFunctional() && (!industry.isUpgrading() || industry.getId().equals(Industries.POPULATION)) && !industry.isHidden() && !industry.isDisrupted()) {
                                                float weight = 1f;
                                                if (SupportedIndustries != null && SupportedIndustries.get(industry.getId()) != null) {weight = SupportedIndustries.get(industry.getId());}
                                                AmongUs.add(industry.getId(), weight);
                                            }
                                        }
                                        String industryid = AmongUs.pick();
                                        if (industryid != null) {market.getIndustry(industryid).setImproved(true);
                                            if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCIntelText") : Global.getSettings().getBoolean("BCIntelText") && !market.isHidden()) {
                                                text.add(String.format(Global.getSettings().getString("bettercolonies", "SPDescription"), market.getName(), market.getIndustry(industryid).getCurrentName()));
                                                factionColor.add(market.getFaction().getColor());
                                                highlighttext.add(market.getName());
                                                highlighttext2.add(market.getIndustry(industryid).getCurrentName());
                                            }
                                        }
                                   }
                                } 
                            }
                        }
                    } else {
                        for (String factionid : SupportedFaction) {
                             for (MarketAPI market : Misc.getFactionMarkets(factionid)) {
                                if (market != null && Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= (Global.getSector().getFaction(factionid).getCustomBoolean("decentralized") ? (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCInnovatedDecentralized") : Global.getSettings().getFloat("BCInnovatedDecentralized")) : (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCInnovatedCentralized") : Global.getSettings().getFloat("BCInnovatedCentralized")))*market.getIndustries().size()) {
                                    if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 1/Math.pow(Math.max(1f, Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getFloat("timid_admins", "BCSPIndustryMultiplier") : Global.getSettings().getFloat("BCSPIndustryMultiplier")), Misc.getNumImprovedIndustries(market))) {
                                        WeightedRandomPicker<String> AmongUs = new WeightedRandomPicker<String>();
                                        for (Industry industry : market.getIndustries()) {
                                            if (industry.isImproved()) continue;
                                            if (industry.canImprove() && industry.isFunctional() && (!industry.isUpgrading() || industry.getId().equals(Industries.POPULATION)) && !industry.isHidden() && !industry.isDisrupted()) {
                                                float weight = 1f;
                                                if (SupportedIndustries != null && SupportedIndustries.get(industry.getId()) != null) {weight = SupportedIndustries.get(industry.getId());}
                                                AmongUs.add(industry.getId(), weight);
                                            }
                                        }
                                        String industryid = AmongUs.pick();
                                        if (industryid != null) {market.getIndustry(industryid).setImproved(true);
                                            if (Global.getSettings().getModManager().isModEnabled("lunalib") ? LunaSettings.getBoolean("timid_admins", "BCIntelText") : Global.getSettings().getBoolean("BCIntelText") && !market.isHidden()) {
                                                text.add(String.format(Global.getSettings().getString("bettercolonies", "SPDescription"), market.getName(), market.getIndustry(industryid).getCurrentName()));
                                                factionColor.add(market.getFaction().getColor());
                                                highlighttext.add(market.getName());
                                                highlighttext2.add(market.getIndustry(industryid).getCurrentName());
                                            }
                                        }
                                   }
                                } 
                            }
                        }
                        
                    }
                    if (!text.isEmpty()) {
                            bc_SPNotification intel = new bc_SPNotification(String.format(Global.getSettings().getString("bettercolonies", "SPTitle"), date), date, text, factionColor, highlighttext, highlighttext2);
                            Global.getSector().getIntelManager().addIntel(intel, false);
                            Global.getSector().addScript(intel);
                    }
                }
            }
        }
    }
    
}
