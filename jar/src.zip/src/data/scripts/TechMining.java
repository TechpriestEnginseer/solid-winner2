package data.scripts;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.campaign.impl.items.BlueprintProviderItem;
import com.fs.starfarer.api.campaign.impl.items.ModSpecItemPlugin;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.impl.campaign.procgen.SalvageEntityGenDataSpec.DropData;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;


public class TechMining extends BaseIndustry implements MarketImmigrationModifier {

	public static final String TECH_MINING_MULT = "$core_techMiningMult";
	private static boolean bHasAlphaCore = false;
	public void setNewBuild( float progress ) {
		building = true;
		buildProgress = spec.getBuildTime() * progress;
		upgradeId = null;
	}
        @Override
	public void apply() {
		super.apply(false);
		
		int size = market.getSize();

		int max = 0;
		if (market.hasCondition(Conditions.RUINS_VAST)) {
			//max = 7;
			max = 4;
		} else if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) {
			//max = 6;
			max = 3;
		} else if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) {
			//max = 5;
			max = 2;
		} else if (market.hasCondition(Conditions.RUINS_SCATTERED)) {
			//max = 4;
			max = 1;
		}
		
		size = Math.min(size, max);
		
		applyIncomeAndUpkeep(size);
		
//		supply(Commodities.METALS, size + 2);
//		supply(Commodities.HEAVY_MACHINERY, size);
//		supply(Commodities.FUEL, size);
//		supply(Commodities.SUPPLIES, size);
		
//		supply(Commodities.HAND_WEAPONS, size);
//		supply(Commodities.RARE_METALS, size - 2);
//		supply(Commodities.VOLATILES, size - 2);

		if (!isFunctional()) {
			supply.clear();
		}
		
		market.addTransientImmigrationModifier(this);
	}

	
	@Override
	public void unapply() {
		market.removeTransientImmigrationModifier(this);
	}


	@Override
	public boolean isAvailableToBuild() {
		if (!super.isAvailableToBuild()) return false;
		if (market.hasCondition(Conditions.RUINS_VAST) ||
				market.hasCondition(Conditions.RUINS_EXTENSIVE) ||
				market.hasCondition(Conditions.RUINS_WIDESPREAD) ||
				market.hasCondition(Conditions.RUINS_SCATTERED)) {
			return true;
		}
		return false;
	}

	@Override
	public String getUnavailableReason() {
		if (!super.isAvailableToBuild()) return super.getUnavailableReason();
		return "Requires ruins";
	}

	
        @Override
	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		incoming.add(Factions.TRITACHYON, 10f);
	}
	
        @Override
	public float getPatherInterest() {
		float base = 1f;
		if (market.hasCondition(Conditions.RUINS_VAST)) {
			base = 8;
		} else if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) {
			base = 6;
		} else if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) {
			base = 4;
		} else if (market.hasCondition(Conditions.RUINS_SCATTERED)) {
			base = 2;
		}
		return base + super.getPatherInterest();
	}
	
	
        @Override
	protected boolean hasPostDemandSection(boolean hasDemand, IndustryTooltipMode mode) {
		return true;
	}
	
	@Override
	protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode) {
		float opad = 10f;
		tooltip.addPara("In addition to extracting basic resources, " +
				"there's also a chance to find blueprints and other rare items. Anything " +
				"found will be delivered to the designated production gathering point.", opad);
                
		if (market.hasCondition(Conditions.RUINS_VAST)) {
			tooltip.addPara("The vast ruins here offer incredible potential for valuable finds.", opad);
		} else if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) {
			tooltip.addPara("The extensive ruins here offer the opportunity for valuable finds.", opad);
		} else if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) {
			tooltip.addPara("The widespread ruins here offer a solid chance of finding something valuable, given time.", opad);
		} else if (market.hasCondition(Conditions.RUINS_SCATTERED)) {
			tooltip.addPara("The scattered ruins here offer only a slight chance of finding something valuable, though one never knows what might be located given enough time.", opad);
		}
		
		float mult = getTechMiningMult();
                
		if (mult >= .9f) {
			tooltip.addPara("These ruins are largely untapped.", opad);
		} else if (mult >= .5f) {
			tooltip.addPara("These ruins have been stripped of easy pickings, but the more difficult areas remain, filled with promise.", opad);
		} else if (mult >= 0.25f) {
			tooltip.addPara("These ruins have been combed through, though the chance for a few new finds still remains.", opad);
		} else {
			tooltip.addPara("These ruins have been comprehensively combed over multiple times, and there is little chance of a new valuable find.", opad);
		}
                tooltip.addPara("%s%% salvage are still remaining, waiting to be recovered!", opad, Misc.getHighlightColor(), String.format("%.2f", mult*100f));
		// add something re: size of ruins and chance to find stuff
		
	}
	
	public float getTechMiningMult() {
		MemoryAPI mem = market.getMemoryWithoutUpdate();
		if (mem.contains(TECH_MINING_MULT)) {
			return mem.getFloat(TECH_MINING_MULT);
		}
		mem.set(TECH_MINING_MULT, 1f);
		return 1f;
	}
	
	public void setTechMiningMult(float value) {
		MemoryAPI mem = market.getMemoryWithoutUpdate();
		mem.set(TECH_MINING_MULT, value);
	}
	
	public float getTechMiningRuinSizeModifier() {
		return getTechMiningRuinSizeModifier(market);
	}
	
	public static float getTechMiningRuinSizeModifier(MarketAPI market) {
		float mod = 0f;
		if (market.hasCondition(Conditions.RUINS_VAST)) {
			mod = 1;
		} else if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) {
			mod = 0.6f;
		} else if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) {
			mod = 0.35f;
		} else if (market.hasCondition(Conditions.RUINS_SCATTERED)) {
			mod = 0.2f;
		}
		return mod;
	}
        
	@Override
        protected void applyAlphaCoreModifiers() {
            bHasAlphaCore = true;
        }
        
        @Override
        protected void applyNoAICoreModifiers() {
            bHasAlphaCore = false;
        }
        
        @Override
	public CargoAPI generateCargoForGatheringPoint(Random random) {
		if (!isFunctional()) return null;
		
		float mult = getTechMiningMult();
                float AlphaCoreTechMiningMultiplier = Global.getSettings().getFloat("techminingACbonus");
		float decay = MathUtils.getRandomNumberInRange(Global.getSettings().getFloat("techMiningDecay"), 1.00f);
		float base = getTechMiningRuinSizeModifier();
                
		if (bHasAlphaCore) {
                    base = base * AlphaCoreTechMiningMultiplier;
                    decay = 1-(1-decay)*AlphaCoreTechMiningMultiplier;
                }
                
		setTechMiningMult(mult * decay);
		
		List<DropData> dropRandom = new ArrayList<DropData>();
		List<DropData> dropValue = new ArrayList<DropData>();
                
                DropData d = new DropData();
                d.chances = 1;
                d.group = "blueprints_low";
                //d.addCustom("item_:{tags:[single_bp], p:{tags:[rare_bp]}}", 1f);
                dropRandom.add(d);

                d = new DropData();
                d.chances = 1;
                d.group = "rare_tech_low";
                d.valueMult = 0.1f;
                dropRandom.add(d);

                d = new DropData();
                d.chances = 1;
                d.group = "ai_cores3";
                //d.valueMult = 0.1f; // already a high chance to get nothing due to group setup, so don't reduce further
                dropRandom.add(d);

                d = new DropData();
                d.chances = 1;
                d.group = "any_hullmod_low";
                dropRandom.add(d);

                d = new DropData();
                d.chances = 5;
                d.group = "weapons2";
                dropRandom.add(d);

                d = new DropData();
                //d.chances = 100;
                d.group = "basic";
                d.value = 10000;
                dropValue.add(d);
                
		if (mult >= 1) {
			float num = base * (5f + random.nextFloat() * 2f);
			if (base < 1) base = 1;
			
			d = new DropData();
			d.chances = (int) Math.round(num);
			d.group = "techmining_first_find";
			dropRandom.add(d);
		}
		
		CargoAPI result = SalvageEntity.generateSalvage(random, 1f, 1f, base * mult, 1f, dropValue, dropRandom);
		
		FactionAPI pf = Global.getSector().getPlayerFaction();
		OUTER: for (CargoStackAPI stack : result.getStacksCopy()) {
			if (stack.getPlugin() instanceof BlueprintProviderItem) {
				BlueprintProviderItem bp = (BlueprintProviderItem) stack.getPlugin();
				List<String> list = bp.getProvidedShips();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsShip(id)) continue OUTER;
					}
				}
				
				list = bp.getProvidedWeapons();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsWeapon(id)) continue OUTER;
					}
				}
				
				list = bp.getProvidedFighters();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsFighter(id)) continue OUTER;
					}
				}
				
				list = bp.getProvidedIndustries();
				if (list != null) {
					for (String id : list) {
						if (!pf.knowsIndustry(id)) continue OUTER;
					}
				}
				result.removeStack(stack);
			} else if (stack.getPlugin() instanceof ModSpecItemPlugin) {
				ModSpecItemPlugin mod = (ModSpecItemPlugin) stack.getPlugin();
				if (!pf.knowsHullMod(mod.getModId())) continue OUTER;
				result.removeStack(stack);
			}
		}
		
		return result;
	}
        
        /*        @Override
        protected void applyAlphaCoreSupplyAndDemandModifiers() {
        }*/
        @Override
	protected void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
		float opad = 10f;
		Color highlight = Misc.getHighlightColor();
		
		String pre = "Alpha-level AI core currently assigned. ";
		if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			pre = "Alpha-level AI core. ";
		}
		String str = "" + (int) Math.round(Global.getSettings().getFloat("techminingACbonus") * 100f - 100f) + "%";
                
		if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
			CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
			TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
			text.addPara(pre + "Reduces upkeep cost by %s. " +
					"Increases tech-mining potential yields by %s.", 0f, highlight,
					"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", str);
			tooltip.addImageWithText(opad);
			return;
		}
		
		tooltip.addPara(pre + "Reduces upkeep cost by %s. " +
				"Increases tech-mining potential by %s.", opad, highlight,
				"" + (int)((1f - UPKEEP_MULT) * 100f) + "%", str);
		
	}
}







