package com.fs.starfarer.api.impl.campaign.rulecmd;

import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;


public class bc_checkskill extends BaseCommandPlugin {

	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, final Map<String, MemoryAPI> memoryMap) {
		if (dialog == null) return false;
                if (params.size() == 2) {dialog.getInteractionTarget().getActivePerson().getStats().setSkillLevel(params.get(0).getString(memoryMap), 3);dialog.getInteractionTarget().getActivePerson();dialog.getInteractionTarget().getActivePerson().getMemoryWithoutUpdate().set("$ome_salary", Misc.getWithDGS((int) Misc.getAdminSalary(dialog.getInteractionTarget().getActivePerson())));return true;
                }
                return Global.getSector().getPlayerPerson().getStats().hasSkill(params.get(0).getString(memoryMap));
	}
}

