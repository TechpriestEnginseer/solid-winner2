package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import lunalib.lunaSettings.LunaSettings;

/**
 * Modified off AddTextSmall "text OR text OR text" <color>
 * Only does bc_techmine2 <color> <highlight color>
 */

public class bc_techmine2 extends BaseCommandPlugin {
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, Map<String, MemoryAPI> memoryMap) {
                    if (dialog == null) return false;
                    if (Global.getSettings().getModManager().isModEnabled("lunalib") ? !LunaSettings.getBoolean("timid_admins", "BCTechmining") : !Global.getSettings().getBoolean("BCTechmining")) return false;
                    MarketAPI market = null;
                    float mult = 0f;
                    if (dialog.getInteractionTarget() != null) {
                        market = dialog.getInteractionTarget().getMarket();
                        MemoryAPI mem = market.getMemoryWithoutUpdate();
                        if (mem.contains("$core_techMiningMult")) {mult = mem.getFloat("$core_techMiningMult");}
                    }
                    if (mult == 0f || (!dialog.getInteractionTarget().getMarket().isPlayerOwned() && !dialog.getInteractionTarget().getMarket().isPlanetConditionMarketOnly())) return false;
                    String text1 = String.format(Global.getSettings().getString("bettercolonies", "TechMiningDialog1"), String.format("%.2f", mult*100f));//params.get(0).getStringWithTokenReplacement(ruleId, dialog, memoryMap);
                    String text2 = "";
                    if (Global.getSettings().getFloat("techMiningDecay") != 0 && dialog.getInteractionTarget().getMarket().isPlayerOwned()) {text2 = String.format(Global.getSettings().getString("bettercolonies", "TechMiningDialog2"), String.format("%.2f", mult*100f*Global.getSettings().getFloat("techMiningDecay")));}//params.get(0).getStringWithTokenReplacement(ruleId, dialog, memoryMap);
                    String text = text1+" "+text2;
                    if (text == null || text.isEmpty()) return true;

                    String [] split = text.split("(?s)\nOR\n");
                    if (split != null && split.length > 1) {
                            text = split[new Random().nextInt(split.length)];
                            text = text.trim();
                    }

                    Color color = null;
                    if (!params.isEmpty()) {
                            color = params.get(0).getColor(memoryMap);
                    }

                    dialog.getTextPanel().setFontSmallInsignia();
                    dialog.getTextPanel().addParagraph(text, color);
                    List<String> strings = new ArrayList<String>();
                    strings.add(String.format("%.2f", mult*100f));
                    strings.add(String.format("%.2f", mult*100f*Global.getSettings().getFloat("techMiningDecay")));
                    strings.add("%");
                    dialog.getTextPanel().highlightInLastPara(strings.toArray(new String[0]));
                    dialog.getTextPanel().setFontInsignia();
                    return true;
            }
}

