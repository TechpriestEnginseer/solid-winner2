package com.fs.starfarer.api.impl.campaign.rulecmd;

import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.ResourceCostPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import static com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity.COST_HEIGHT;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;


public class bc_techmine extends BaseCommandPlugin {

	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, final Map<String, MemoryAPI> memoryMap) {
		if (dialog == null || dialog.getInteractionTarget() == null || dialog.getInteractionTarget().getMarket() == null) return false;
                if (params.size() < 2) {dialog.getInteractionTarget().getMarket().removeCondition(params.get(0).getString(memoryMap));return true;}
                ResourceCostPanelAPI cost = dialog.getTextPanel().addCostPanel(Global.getSettings().getString("bettercolonies", "Techmine1"), COST_HEIGHT,Global.getSector().getPlayerFaction().getColor(), Global.getSector().getPlayerFaction().getDarkUIColor());
		cost.setNumberOnlyMode(true);
		cost.setWithBorder(false);
		cost.setAlignment(Alignment.LMID);
		cost.addCost(Commodities.CREW, "" + params.get(0).getInt(memoryMap) + " (" + (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.CREW) + ")", params.get(0).getInt(memoryMap) <= (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.CREW) ? Global.getSector().getPlayerFaction().getColor() : Misc.getHighlightColor());
		cost.addCost(Commodities.HEAVY_MACHINERY, "" + params.get(1).getInt(memoryMap) + " (" + (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) + ")", params.get(1).getInt(memoryMap) <= (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) ? Global.getSector().getPlayerFaction().getColor() : Misc.getHighlightColor());
                cost.update();
                if (dialog.getInteractionTarget().getMarket().hasCondition(Conditions.DECIVILIZED) || dialog.getInteractionTarget().getMarket().hasCondition(Conditions.DECIVILIZED_SUBPOP)) {
                    ResourceCostPanelAPI cost2 = dialog.getTextPanel().addCostPanel(Global.getSettings().getString("bettercolonies", "Techmine2"), COST_HEIGHT,Global.getSector().getPlayerFaction().getColor(), Global.getSector().getPlayerFaction().getDarkUIColor());
                    cost2.setNumberOnlyMode(true);
                    cost2.setWithBorder(false);
                    cost2.setAlignment(Alignment.LMID);
                    cost2.addCost(Commodities.MARINES, "" +  Misc.getRoundedValue((float) (params.get(0).getInt(memoryMap)*0.4)) + " (" + (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.MARINES) + ")", (int) params.get(0).getInt(memoryMap) * 0.4 <= (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.MARINES) ? Global.getSector().getPlayerFaction().getColor() : Misc.getNegativeHighlightColor());
                    cost2.update();
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_marines", Misc.getRoundedValue((float) (params.get(0).getInt(memoryMap)*0.4)));
                }
                if (Misc.getClaimingFaction(dialog.getInteractionTarget()) != null) {
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_factioncolor", Misc.getClaimingFaction(dialog.getInteractionTarget()).getColor(), 0f);
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_factionstring", Misc.getClaimingFaction(dialog.getInteractionTarget()).getDisplayName(), 0f);
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_factionid", Misc.getClaimingFaction(dialog.getInteractionTarget()).getId(), 0f);
                }
		return true;
	}
}

